import Hpb from './Hpb';

function App() {
  return <Hpb />;
}

export default App;
